import tkinter as tk
from tkinter import *

BG_GRAY = '#ABB2B9'
BG_COLOR = '#17202A'
TEXT_COLOR = '#EAECEE'

FONT = 'Helvetica 14'
FONT_BOLD = 'Helvetica 13 bold'
root = tk.Tk()
label = tk.Label(root,text='WELCOME',font=(FONT_BOLD) ,background= BG_GRAY,foreground= TEXT_COLOR)
label.place(relwidth=1)
label.pack()

